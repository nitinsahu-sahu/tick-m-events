export * from './event-details-view';
